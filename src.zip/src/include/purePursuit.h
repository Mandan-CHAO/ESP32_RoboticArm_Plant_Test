#ifndef purePursuit_H
#define purePursuit_H


#include <iostream>

#include "ros/ros.h"

#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>

#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>


class purePursuit{
    public:
        purePursuit();
       
        void init();
        void odomCallback(const nav_msgs::Odometry::ConstPtr &odomMsg);
        void pathCallback(const nav_msgs::Path::ConstPtr &PathMsgs);
        //void goalCallback(const geometry_msgs::PoseStamped::ConstPtr &goalMsg);
        void setTwist(const ros::TimerEvent&);

        void wayPttfodm();

        int findWaypoint(int localPathNum);
        double calculateDistance(geometry_msgs::PoseStamped& wayPoint, const geometry_msgs::PoseWithCovariance carPose);

    private:
        int index, wayPtIndex;
        double base_length, v_ref, lfd;
        int controlFreq;
        double tolerance;

        ros::Subscriber odom_sub, path_sub;
        ros::Publisher control_pub;
        ros::Timer timer1, timer2;

        geometry_msgs::Point odom_goal_pt, goal_pt;
        geometry_msgs::Twist ctrl_twist;
        nav_msgs::Odometry odom;
        nav_msgs::Path global_path, local_path, odom_path;

};

#endif