/*

*/

#include "include/purePursuit.h"

purePursuit::purePursuit(){
    
    // Create the private node for pure pursuit
    ros::NodeHandle private_node("tracking_private");
    // Create the public node for
    ros::NodeHandle public_node("tracking_public");

    //set the param of SCOUTMINI wheelbase (unit:m)
    private_node.param("base_length", base_length, 0.451); 
    //set the param of expected velocity (unit:m/s)
    private_node.param("v_ref", v_ref, 0.5);
    //set the default param of look-forward distance (unit:m)
    private_node.param("lfd", lfd, 0.1);


    //set the params of controller
    private_node.param("controlFreq", controlFreq, 50);
    private_node.param("tolerance", tolerance, 0.1);


    //set the publishers and subscribers
    odom_sub = public_node.subscribe("/odom", 1, &purePursuit::odomCallback, this);
    path_sub = public_node.subscribe("/path", 1, &purePursuit::pathCallback, this);
    control_pub = public_node.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    timer1 = public_node.createTimer(ros::Duration((1.0)/controlFreq), &purePursuit::setTwist, this);
    

}

void purePursuit::init(){
    
}


/*!
*
* @param wayPoint given by the /path
* @param carPose given by /odom
* @return the distance between the current pose and the selected waypoint
*/
double purePursuit::calculateDistance(geometry_msgs::PoseStamped& wayPoint, const geometry_msgs::PoseWithCovariance carPose){
    double dx = wayPoint.pose.position.x - carPose.pose.position.x;
    double dy = wayPoint.pose.position.y - carPose.pose.position.y;
    double dz = dx*dx + dy*dy;
    return dz;
}

/*!
*
* @param odomMsgs the /odom publish data
* @details subscribe the /odom data and use this data to judge whether the car reached the goal
* @author trying to get the current pose of car?
*/
void purePursuit::odomCallback(const nav_msgs::Odometry::ConstPtr &odomMsg){
    this->odom = *odomMsg;

}


/*!
*
* @param pathMsgs the /path publish data
* @details subscribe the /path data and use this data to judge whether the car reached the goal
* @author trying to read the path (global?local?)
*/
void purePursuit::pathCallback(const nav_msgs::Path::ConstPtr &pathMsg){
    this->global_path = *pathMsg;

}


/*!
*
* @param timer for sending the command at the selected frequency
* @details control publisher publish the twist to /cmd_vel to drive the car
* @author TODO:modifying the calculation of expected velocity
*/
void purePursuit::setTwist(const ros::TimerEvent&){
    
    double vel_x = 1.0;
    double vel_y = 0.0;
    double vel_angular = 0.0;
    this->ctrl_twist.linear.x = vel_x;
    this->ctrl_twist.linear.y = vel_y;
    this->ctrl_twist.angular.z = vel_angular;

    this->control_pub.publish(this->ctrl_twist);
}


/*!
*
* @param localPathNum the number of local path waypoint, use this param to change the waypoint range
* @details find the nearest point in the local/global path
*/
int purePursuit::findWaypoint(int localPathNum){
    int index_min = this->index;
    int threshold = this->lfd;
    int d_min = INT16_MAX;
    for(int i = index_min; i < this->global_path.poses.size() && i < (index_min+localPathNum); i++){
        geometry_msgs::PoseStamped pathPoint = this->global_path.poses[i];
        double d_temp = calculateDistance(pathPoint, this->odom.pose);
        if (d_temp < d_min && d_temp > threshold){
            d_min = d_temp;
            this->wayPtIndex = i;
        }
    }
    return this->wayPtIndex;
}

/*!
*
* @param 
* @details transform the waypoint pose in the map coordinate to the (car) odom coordinate
* @author TODO: !!!need to change the quaternion to angle along the z-axis!!!
*/
void purePursuit::wayPttfodm(){
    wayPtIndex = findWaypoint(10);
    geometry_msgs::PoseWithCovariance carPose = this->odom.pose;
    geometry_msgs::PoseStamped wayPoint = this->global_path.poses[wayPtIndex];
    double dx = wayPoint.pose.position.x - carPose.pose.position.x;
    double dy = wayPoint.pose.position.y - carPose.pose.position.y;
    double da = wayPoint.pose.orientation.z - carPose.pose.orientation.z;
}





int main(int argc, char **argv){
    ros::init(argc, argv, "purePursuit");
    purePursuit pptracking;

    ros::AsyncSpinner spinner(3);
    spinner.start();
    ros::waitForShutdown();
    return 0;
}

